import React from 'react'
import '../css/Loading.css'
import image from '../img/loading.gif'
export const Loading = () => {
  return (
    <img src={image} alt="" />
  )
}
